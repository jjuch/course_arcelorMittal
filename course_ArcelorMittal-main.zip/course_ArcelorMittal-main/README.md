# course_ArcelorMittal
Course files for ArcelorMittal training on 08/12/2023